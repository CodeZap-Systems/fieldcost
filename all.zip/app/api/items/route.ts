import { NextResponse } from 'next/server';
import { supabaseServer } from '../../../lib/supabaseServer';
import { resolveServerUserId } from '../../../lib/serverUser';
import { ensureAuthUser, EnsureAuthUserError } from '../../../lib/demoAuth';
import { DEMO_COMPANY_ID } from '../../../lib/demoConstants';
import { isDemoUserId } from '../../../lib/userIdentity';
import { getCompanyContext } from '../../../lib/companyContext';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = resolveServerUserId(undefined);
    const companyIdParam = searchParams.get('company_id');
    
    // CRITICAL: Enforce company_id requirement for data isolation (GDPR/POPIA)
    if (!companyIdParam || !companyIdParam.trim()) {
      console.warn(`[SECURITY] GET /api/items: Missing company_id for user ${userId}`);
      return NextResponse.json(
        { error: 'company_id parameter is required for data isolation' },
        { status: 400 }
      );
    }

    // Convert company_id: try as integer first, fallback to string (for demo IDs like "demo-company-id")
    let companyId: string | number = companyIdParam.trim();
    const asInt = parseInt(companyId, 10);
    if (Number.isFinite(asInt)) {
      companyId = asInt;  // DB real companies use integers
    }
    // Otherwise keep as string (for demo company IDs)
    
    // Get items from database with strict company isolation
    if (userId && userId !== 'demo-user') {
      let query = supabaseServer
        .from('items')
        .select('*')
        .eq('user_id', userId)
        .eq('company_id', companyId);  // CRITICAL: Both user AND company must match
      
      const { data, error } = await query;
      
      if (!error && Array.isArray(data)) {
        return NextResponse.json(data);
      }
      return NextResponse.json([]);
    } else {
      // Demo user: only allow demo company_id set in demoConstants
      if (companyId !== DEMO_COMPANY_ID) {
        console.warn(`[SECURITY] Demo user attempted to access non-demo company ${companyId}, expected ${DEMO_COMPANY_ID}`);
        return NextResponse.json([], { status: 403 });
      }
      
      let query = supabaseServer
        .from('items')
        .select('*')
        .eq('company_id', companyId);
      
      const { data, error } = await query;
      return NextResponse.json(!error && Array.isArray(data) ? data : []);
    }
  } catch (e) {
    console.error('GET /api/items error:', e);
    return NextResponse.json([]);
  }
}

export async function POST(req: Request) {
  const body = await req.json();
  const userId = resolveServerUserId(body.user_id);
  const companyId = body.company_id;
  
  if (!userId) {
    return NextResponse.json({ error: 'User ID required' }, { status: 400 });
  }

  try {
    await ensureAuthUser(userId);
  } catch (error) {
    if (error instanceof EnsureAuthUserError) {
      return NextResponse.json({ error: error.message }, { status: error.statusCode });
    }
    console.error('POST /api/items ensureAuthUser error:', error);
    return NextResponse.json({ error: 'Unable to prepare user context' }, { status: 500 });
  }

  try {
    const { companyId: validCompanyId } = await getCompanyContext(userId, companyId);
    
    const payload = {
      name: body.name,
      price: body.price ?? null,
      stock_in: body.stock_in ?? 0,
      stock_used: body.stock_used ?? 0,
      item_type: body.item_type ?? 'physical',
      user_id: userId,
      ...(body.company_id !== undefined && { company_id: validCompanyId })
    };
    
    const { data, error } = await supabaseServer.from('items').insert([payload]).select();
    
    if (error) {
      // If schema cache error, try without company_id
      if (error.message?.includes('company_id')) {
        const simplePayload = {
          name: body.name,
          price: body.price ?? null,
          stock_in: body.stock_in ?? 0,
          stock_used: body.stock_used ?? 0,
          item_type: body.item_type ?? 'physical',
          user_id: userId
        };
        const { data: simpleData, error: simpleError } = await supabaseServer
          .from('items')
          .insert([simplePayload])
          .select();
        
        if (simpleError) {
          console.error('POST /api/items error:', simpleError);
          return NextResponse.json({ error: simpleError.message }, { status: 500 });
        }
        
        return NextResponse.json({
          ...simpleData[0],
          company_id: validCompanyId
        }, { status: 201 });
      }
      
      console.error('POST /api/items error:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({
      ...data[0],
      company_id: validCompanyId
    }, { status: 201 });
  } catch (err) {
    console.error('POST /api/items exception:', err);
    return NextResponse.json({ error: String(err) }, { status: 400 });
  }
}

export async function PATCH(req: Request) {
  const body = await req.json();
  const { id, user_id: incomingUserId, company_id: incomingCompanyId, ...fields } = body;
  const userId = resolveServerUserId(incomingUserId);
  const companyId = incomingCompanyId;
  
  if (!userId || !id) {
    return NextResponse.json({ error: 'User ID and item ID required' }, { status: 400 });
  }

  try {
    const { companyId: validCompanyId } = await getCompanyContext(userId, companyId);
    
    const { data, error } = await supabaseServer
      .from('items')
      .update(fields)
      .eq('id', id)
      .eq('user_id', userId)
      .eq('company_id', validCompanyId)
      .select();
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json(data[0]);
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  const { id, user_id: incomingUserId, company_id: incomingCompanyId } = await req.json();
  const userId = resolveServerUserId(incomingUserId);
  const companyId = incomingCompanyId;
  
  if (!userId || !id) {
    return NextResponse.json({ error: 'User ID and item ID required' }, { status: 400 });
  }

  try {
    const { companyId: validCompanyId } = await getCompanyContext(userId, companyId);
    
    const { error } = await supabaseServer
      .from('items')
      .delete()
      .eq('id', id)
      .eq('user_id', userId)
      .eq('company_id', validCompanyId);
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ success: true });
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 400 });
  }
}
