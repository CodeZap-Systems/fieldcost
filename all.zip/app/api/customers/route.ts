import { NextResponse } from 'next/server';
import { supabaseServer } from '../../../lib/supabaseServer';
import { resolveServerUserId } from '../../../lib/serverUser';
import { ensureAuthUser, EnsureAuthUserError } from '../../../lib/demoAuth';
import { DEMO_COMPANY_ID } from '../../../lib/demoConstants';
import { isDemoUserId } from '../../../lib/userIdentity';
import { getCompanyContext } from '../../../lib/companyContext';

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const userId = resolveServerUserId(undefined);
    const companyIdParam = searchParams.get('company_id');
    
    // CRITICAL: Enforce company_id requirement for data isolation (GDPR/POPIA)
    if (!companyIdParam || !companyIdParam.trim()) {
      console.warn(`[SECURITY] GET /api/customers: Missing company_id for user ${userId}`);
      return NextResponse.json(
        { error: 'company_id parameter is required for data isolation' },
        { status: 400 }
      );
    }

    // Convert company_id: try as integer first, fallback to string (for demo IDs like "demo-company-id")
    let companyId: string | number = companyIdParam.trim();
    const asInt = parseInt(companyId, 10);
    if (Number.isFinite(asInt)) {
      companyId = asInt;  // DB real companies use integers
    }
    // Otherwise keep as string (for demo company IDs)
    
    // Get customers from database with strict company isolation
    if (userId && userId !== 'demo-user') {
      let query = supabaseServer
        .from('customers')
        .select('*')
        .eq('user_id', userId)
        .eq('company_id', companyId);  // CRITICAL: Both user AND company must match
      
      const { data, error } = await query;
      
      if (!error && Array.isArray(data)) {
        return NextResponse.json(data);
      }
      return NextResponse.json([]);
    } else {
      // Demo user: only allow demo company_id set in demoConstants
      if (companyId !== DEMO_COMPANY_ID) {
        console.warn(`[SECURITY] Demo user attempted to access non-demo company ${companyId}, expected ${DEMO_COMPANY_ID}`);
        return NextResponse.json([], { status: 403 });
      }
      
      let query = supabaseServer
        .from('customers')
        .select('*')
        .eq('company_id', companyId);
      
      const { data, error } = await query;
      return NextResponse.json(!error && Array.isArray(data) ? data : []);
    }
  } catch (e) {
    console.error('GET /api/customers error:', e);
    return NextResponse.json([]);
  }
}

export async function POST(req: Request) {
  const body = await req.json();
  const userId = resolveServerUserId(body.user_id);
  const companyId = body.company_id;
  
  if (!userId) {
    return NextResponse.json({ error: 'User ID required' }, { status: 400 });
  }

  try {
    await ensureAuthUser(userId);
  } catch (error) {
    if (error instanceof EnsureAuthUserError) {
      return NextResponse.json({ error: error.message }, { status: error.statusCode });
    }
    console.error('POST /api/customers ensureAuthUser error:', error);
    return NextResponse.json({ error: 'Unable to prepare user context' }, { status: 500 });
  }

  // Determine company ID with fallback for demo users
  const isDemoUser = userId === 'demo' || userId?.startsWith('demo-');
  let validCompanyId = 1; // Default demo company
  
  try {
    const context = await getCompanyContext(userId, companyId);
    validCompanyId = context.companyId;
  } catch (contextError) {
    console.warn(`[POST /api/customers] getCompanyContext failed for user ${userId}:`, contextError);
    if (!isDemoUser) {
      return NextResponse.json({ error: 'Unable to prepare user context' }, { status: 500 });
    }
    console.log(`[POST /api/customers] Using demo company fallback for user: ${userId}`);
    // Demo users fall back to company_id = 1
  }
  
  try {
    
    // Build payload - exclude company_id if it's not needed or causes schema errors
    const payload = { 
      name: body.name,
      email: body.email ?? null,
      user_id: userId,
      ...(body.company_id !== undefined && { company_id: validCompanyId })
    };
    
    const { data, error } = await supabaseServer.from('customers').insert([payload]).select();
    
    if (error) {
      // If schema cache error, try without company_id
      if (error.message?.includes('company_id')) {
        const simplePayload = {
          name: body.name,
          email: body.email ?? null,
          user_id: userId
        };
        const { data: simpleData, error: simpleError } = await supabaseServer
          .from('customers')
          .insert([simplePayload])
          .select();
        
        if (simpleError) {
          console.error('POST /api/customers error:', simpleError);
          return NextResponse.json({ error: simpleError.message }, { status: 500 });
        }
        
        // Add company_id to response for consistency
        return NextResponse.json({
          ...simpleData[0],
          company_id: validCompanyId
        });
      }
      
      console.error('POST /api/customers error:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }
    
    return NextResponse.json({
      ...data[0],
      company_id: validCompanyId
    });
  } catch (err) {
    console.error('POST /api/customers exception:', err);
    return NextResponse.json({ error: String(err) }, { status: 400 });
  }
}

export async function PATCH(req: Request) {
  const body = await req.json();
  const { id, user_id: incomingUserId, company_id: incomingCompanyId, ...fields } = body;
  const userId = resolveServerUserId(incomingUserId);
  const companyId = incomingCompanyId;
  
  if (!userId || !id) {
    return NextResponse.json({ error: 'User ID and customer ID required' }, { status: 400 });
  }

  try {
    const { companyId: validCompanyId } = await getCompanyContext(userId, companyId);
    
    const { data, error } = await supabaseServer
      .from('customers')
      .update(fields)
      .eq('id', id)
      .eq('user_id', userId)
      .eq('company_id', validCompanyId)
      .select();
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json(data[0]);
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 400 });
  }
}

export async function DELETE(req: Request) {
  const { id, user_id: incomingUserId, company_id: incomingCompanyId } = await req.json();
  const userId = resolveServerUserId(incomingUserId);
  const companyId = incomingCompanyId;
  
  if (!userId || !id) {
    return NextResponse.json({ error: 'User ID and customer ID required' }, { status: 400 });
  }

  try {
    const { companyId: validCompanyId } = await getCompanyContext(userId, companyId);
    
    const { error } = await supabaseServer
      .from('customers')
      .delete()
      .eq('id', id)
      .eq('user_id', userId)
      .eq('company_id', validCompanyId);
    if (error) return NextResponse.json({ error: error.message }, { status: 500 });
    return NextResponse.json({ success: true });
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 400 });
  }
}
