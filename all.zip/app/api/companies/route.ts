/**
 * API: Companies Management
 * GET /api/companies - List all companies for current user
 * GET /api/companies/:id - Get specific company details
 */

import { NextRequest, NextResponse } from "next/server";
import { supabaseServer } from "@/lib/supabaseServer";
import { resolveServerUserId } from "@/lib/serverUser";

/**
 * Mark company as demo based on certain criteria
 */
function markDemoCompany(company: any) {
  return {
    ...company,
    is_demo_company: 
      company.name?.toLowerCase().includes('demo') ||
      company.name?.toLowerCase().includes('test'),
  };
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = resolveServerUserId(searchParams.get('user_id'));
    const companyId = searchParams.get("id");

    // CRITICAL: Filter by user_id to prevent data leakage between accounts
    if (!userId) {
      return NextResponse.json({
        companies: [],
        total: 0,
      });
    }

    try {
      // Get ONLY companies belonging to the authenticated user
      const { data: companies, error } = await supabaseServer
        .from("company_profiles")
        .select("*")
        .eq("user_id", userId)
        .limit(50);

      if (error) {
        console.error("Database error:", error);
        return NextResponse.json({
          companies: [],
          total: 0,
        });
      }

      // Mark demo companies and add is_demo_company flag
      const companiesWithDemo = (companies || []).map(markDemoCompany);

      // If looking for specific company
      if (companyId) {
        const company = companiesWithDemo.find(c => c.id === parseInt(companyId, 10));
        if (company) {
          return NextResponse.json({ company });
        }
        return NextResponse.json(
          { error: "Company not found" },
          { status: 404 }
        );
      }

      return NextResponse.json({
        companies: companiesWithDemo,
        total: companiesWithDemo.length,
      });
    } catch (dbError) {
      console.error("Database error fetching companies:", dbError);
      return NextResponse.json({
        companies: [],
        total: 0,
      });
    }
  } catch (err) {
    console.error("Error in GET /api/companies:", err);
    return NextResponse.json({
      companies: [],
      total: 0,
    });
  }
}
