import { NextResponse } from 'next/server';
import { supabaseServer } from '../../../lib/supabaseServer';
import { resolveServerUserId } from '../../../lib/serverUser';
import { ensureAuthUser, EnsureAuthUserError } from '../../../lib/demoAuth';

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const userId = resolveServerUserId(searchParams.get('user_id'));
  const companyIdParam = searchParams.get('company_id');

  // CRITICAL: Enforce company_id requirement for data isolation (GDPR/POPIA)
  if (!companyIdParam || !companyIdParam.trim()) {
    console.warn(`[SECURITY] GET /api/crew: Missing company_id for user ${userId}`);
    return NextResponse.json(
      { error: 'company_id parameter is required for data isolation' },
      { status: 400 }
    );
  }

  // Convert company_id: try as integer first, fallback to string (for demo IDs like "demo-company-id")
  let companyId: string | number = companyIdParam.trim();
  const asInt = parseInt(companyId, 10);
  if (Number.isFinite(asInt)) {
    companyId = asInt;  // DB real companies use integers
  }
  // Otherwise keep as string (for demo company IDs)
  
  let query = supabaseServer
    .from('crew_members')
    .select('*')
    .eq('company_id', companyId)  // CRITICAL: Enforce company isolation
    .order('name', { ascending: true });
    
  if (userId) {
    query = query.eq('user_id', userId);  // CRITICAL: Both user AND company must match
  }
  
  const { data, error } = await query;
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data ?? []);
}

export async function POST(req: Request) {
  const body = await req.json();
  const userId = resolveServerUserId(body.user_id);
  const companyId = body.company_id;
  
  try {
    await ensureAuthUser(userId);
  } catch (error) {
    if (error instanceof EnsureAuthUserError) {
      return NextResponse.json({ error: error.message }, { status: error.statusCode });
    }
    console.error('POST /api/crew ensureAuthUser error:', error);
    return NextResponse.json({ error: 'Unable to prepare user context' }, { status: 500 });
  }

  const payload = {
    name: body.name,
    hourly_rate: typeof body.hourly_rate === 'number' ? body.hourly_rate : Number(body.hourly_rate) || 0,
    user_id: userId,
    ...(companyId !== undefined && { company_id: companyId })
  };

  const { data, error } = await supabaseServer.from('crew_members').insert([payload]).select();
  if (error) {
    console.error('POST /api/crew error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
  return NextResponse.json(data?.[0]);
}
